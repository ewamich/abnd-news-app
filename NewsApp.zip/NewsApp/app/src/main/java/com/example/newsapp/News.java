package com.example.newsapp;

public class News {

    private String mTitle;
    private String mSection;
    private String mTimeInMiliseconds;
    private String mNewsUrl;
    private String mContributor;

    public News(String title, String section, String time, String newsUrl, String contributor){
        mTitle = title;
        mSection = section;
        mTimeInMiliseconds = time;
        mNewsUrl = newsUrl;
        mContributor = contributor;
    }

    public String getmTitle() {
        return mTitle;
    }

    public String getmTimeInMiliseconds() {
        return mTimeInMiliseconds;
    }

    public String getmSection() {
        return mSection;
    }

    public String getmNewsUrl() {
        return mNewsUrl;
    }

    public String getmContributor() {
        return mContributor;
    }
}
