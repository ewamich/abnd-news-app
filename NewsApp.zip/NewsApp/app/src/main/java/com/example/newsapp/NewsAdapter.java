package com.example.newsapp;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;


public class NewsAdapter extends ArrayAdapter<News> {



    public NewsAdapter(Activity context, ArrayList<News> news) {
        super(context, 0, news);
    }


    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.news_item, parent, false);
        }

        //get current news item position
        final News current = getItem(position);

        TextView titleView = (TextView) listItemView.findViewById(R.id.title_view);
        titleView.setText(current.getmTitle());

        TextView sectionView = (TextView) listItemView.findViewById((R.id.section));
        sectionView.setText(current.getmSection());

        // Find the TextView with view ID date
        TextView dateView = (TextView) listItemView.findViewById(R.id.date);
        dateView.setText(current.getmTimeInMiliseconds());

        TextView authorView = (TextView) listItemView.findViewById(R.id.news_author);
        authorView.setText("author: "+current.getmContributor());

        View newsView = listItemView.findViewById(R.id.news_details_view);


        return listItemView;
    }




    }

